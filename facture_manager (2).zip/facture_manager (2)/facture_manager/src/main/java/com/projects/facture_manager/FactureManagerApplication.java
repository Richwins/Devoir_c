package com.projects.facture_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class FactureManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactureManagerApplication.class, args);

		System.out.println("voilà j'essai");
	}

}

package com.projects.facture_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactureManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
